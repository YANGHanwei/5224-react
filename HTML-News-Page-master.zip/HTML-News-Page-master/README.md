# HTML-News-Page
基于BootStrap使用HTML编写的新闻模板

## 1.新闻首页
<img src="https://github.com/jkdev-cn/HTML-News-Page/blob/master/res/01.png"/>

## 2.用户注册页
<img src="https://github.com/jkdev-cn/HTML-News-Page/blob/master/res/02.png"/>

## 3.新闻详情页
<img src="https://github.com/jkdev-cn/HTML-News-Page/blob/master/res/03.png"/>
<br>
